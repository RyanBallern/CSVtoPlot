# NEUROMORPHOLOGICAL DATA ANALYZER - DEVELOPMENT GUIDE
## Part 6 of 10: Export Functionality

**Previous:** [Part 5 - Plotting Engine]  
**Next:** [Part 7 - Analysis Profiles]

---

### 5. EXPORT FUNCTIONALITY

#### 5.1 Export Configuration

**Implementation: `core/exporters/export_config.py`**

```python
from dataclasses import dataclass
from typing import List, Set, Optional, Dict

@dataclass
class ExportConfig:
    """Configuration for export operations."""
    
    # Format toggles
    export_excel: bool = True
    export_graphpad: bool = False  # Toggle GraphPad export
    export_csv: bool = False
    export_statistics_tables: bool = True
    
    # Plot toggles
    export_plots: bool = True
    plot_formats: List[str] = None  # ['png', 'tif']
    plot_dpi: int = 800
    
    # Plot type selection
    plot_types: Set[str] = None  # {'boxplot', 'barplot', 'frequency_count', etc.}
    
    # Condition selection
    selected_conditions: Optional[List[str]] = None  # None = all conditions
    
    # Parameter selection
    selected_parameters: List[str] = None
    
    # Dataset splitting
    split_by_marker: bool = False
    marker_names: Optional[Dict[str, str]] = None  # {'L': 'Liposomes', 'T': 'Tubules'}
    
    def __post_init__(self):
        """Set defaults."""
        if self.plot_formats is None:
            self.plot_formats = ['png', 'tif']
        
        if self.plot_types is None:
            self.plot_types = {
                'boxplot_total',
                'boxplot_relative',
                'barplot_total',
                'barplot_relative',
                'frequency_count',
                'frequency_relative'
            }
    
    def should_export_plot_type(self, plot_type: str) -> bool:
        """Check if a plot type should be exported."""
        return plot_type in self.plot_types
    
    def should_include_condition(self, condition: str) -> bool:
        """Check if a condition should be included in export."""
        if self.selected_conditions is None:
            return True  # Include all
        return condition in self.selected_conditions
    
    def get_active_plot_types(self) -> List[str]:
        """Get list of active plot types."""
        return sorted(self.plot_types)
```

#### 5.2 Parameter Selector for Export

**Implementation: `core/exporters/parameter_selector.py`**

```python
from typing import List, Set

class ExportParameterSelector:
    """Manages parameter selection for export."""
    
    def __init__(self, database: DatabaseInterface):
        self.database = database
        self.selected_parameters: Set[str] = set()
    
    def get_available_parameters(self, assay_ids: List[int]) -> List[str]:
        """Get all parameters available in specified assays."""
        return self.database.get_available_parameters(assay_ids)
    
    def select_parameters(self, parameters: List[str]) -> None:
        """Select parameters for export."""
        self.selected_parameters = set(parameters)
    
    def select_all(self, assay_ids: List[int]) -> None:
        """Select all available parameters."""
        all_params = self.get_available_parameters(assay_ids)
        self.selected_parameters = set(all_params)
    
    def get_selected(self) -> List[str]:
        """Get currently selected parameters."""
        return sorted(self.selected_parameters)
```

#### 5.3 Statistics Table Exporter

**Implementation: `core/exporters/statistics_table_exporter.py`**

```python
import pandas as pd
from pathlib import Path
from typing import Dict, List
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, PatternFill

class StatisticsTableExporter:
    """Exports comprehensive statistical results as formatted tables."""
    
    def __init__(self, stats_engine: StatisticsEngine):
        self.stats = stats_engine
    
    def create_statistics_tables(self, data: Dict[str, pd.Series],
                                 parameter_name: str) -> Dict[str, pd.DataFrame]:
        """
        Create comprehensive statistical tables.
        
        Returns:
            Dict with 'summary', 'anova', 'pairwise' DataFrames
        """
        tables = {}
        
        # 1. Summary statistics table
        tables['summary'] = self._create_summary_table(data, parameter_name)
        
        # 2. ANOVA results table
        tables['anova'] = self._create_anova_table(data, parameter_name)
        
        # 3. Pairwise comparisons table
        tables['pairwise'] = self._create_pairwise_table(data, parameter_name)
        
        return tables
    
    def _create_summary_table(self, data: Dict[str, pd.Series],
                             parameter_name: str) -> pd.DataFrame:
        """Create summary statistics table with values."""
        rows = []
        
        for condition, series in data.items():
            stats = self.stats.calculate_summary_stats(series)
            rows.append({
                'Parameter': parameter_name,
                'Condition': condition,
                'N': stats['n'],
                'Mean': f"{stats['mean']:.3f}",
                'SEM': f"{stats['sem']:.3f}",
                'SD': f"{stats['std']:.3f}",
                'Median': f"{stats['median']:.3f}",
                'Min': f"{stats['min']:.3f}",
                'Max': f"{stats['max']:.3f}",
                'Q25': f"{stats['q25']:.3f}",
                'Q75': f"{stats['q75']:.3f}"
            })
        
        return pd.DataFrame(rows)
    
    def _create_anova_table(self, data: Dict[str, pd.Series],
                           parameter_name: str) -> pd.DataFrame:
        """Create ANOVA results table."""
        anova_result = self.stats.anova_one_way(data)
        
        rows = [{
            'Parameter': parameter_name,
            'Test': 'One-way ANOVA',
            'F-statistic': f"{anova_result['f_statistic']:.4f}",
            'p-value': f"{anova_result['p_value']:.4e}",
            'Significant': 'Yes' if anova_result['is_significant'] else 'No',
            'Alpha': self.stats.alpha
        }]
        
        # Add normality test results
        for condition, norm_result in anova_result['normality_tests'].items():
            rows.append({
                'Parameter': parameter_name,
                'Test': f'Normality ({condition})',
                'F-statistic': '-',
                'p-value': f"{norm_result['p_value']:.4e}",
                'Significant': 'Normal' if norm_result['is_normal'] else 'Non-normal',
                'Alpha': self.stats.alpha
            })
        
        return pd.DataFrame(rows)
    
    def _create_pairwise_table(self, data: Dict[str, pd.Series],
                              parameter_name: str) -> pd.DataFrame:
        """Create pairwise comparisons table."""
        comparisons = self.stats.pairwise_comparisons(data)
        
        if not comparisons:
            return pd.DataFrame({
                'Parameter': [parameter_name],
                'Group 1': ['No significant'],
                'Group 2': ['differences found'],
                'Mean Difference': ['-'],
                'p-value': ['-'],
                'Significant': ['No']
            })
        
        rows = []
        for comp in comparisons:
            rows.append({
                'Parameter': parameter_name,
                'Group 1': comp['group1'],
                'Group 2': comp['group2'],
                'Mean Difference': f"{comp['mean_diff']:.3f}",
                'p-value': f"{comp['p_value']:.4e}",
                'Significant': self._get_significance_level(comp['p_value'])
            })
        
        return pd.DataFrame(rows)
    
    def _get_significance_level(self, p_value: float) -> str:
        """Convert p-value to significance level."""
        if p_value < 0.001:
            return '*** (p<0.001)'
        elif p_value < 0.01:
            return '** (p<0.01)'
        elif p_value < 0.05:
            return '* (p<0.05)'
        else:
            return 'ns (p≥0.05)'
    
    def export_to_excel(self, tables: Dict[str, pd.DataFrame],
                       output_path: Path) -> None:
        """Export statistical tables to formatted Excel file."""
        wb = Workbook()
        wb.remove(wb.active)
        
        # Create worksheets for each table type
        for table_name, df in tables.items():
            ws = wb.create_sheet(table_name.capitalize())
            
            # Write header
            for col_idx, col_name in enumerate(df.columns, 1):
                cell = ws.cell(row=1, column=col_idx, value=col_name)
                cell.font = Font(bold=True, size=12, color='FFFFFF')
                cell.fill = PatternFill(
                    start_color='366092', end_color='366092', fill_type='solid'
                )
                cell.alignment = Alignment(horizontal='center', vertical='center')
            
            # Write data
            for row_idx, row in enumerate(df.itertuples(index=False), 2):
                for col_idx, value in enumerate(row, 1):
                    cell = ws.cell(row=row_idx, column=col_idx, value=value)
                    cell.alignment = Alignment(horizontal='center', vertical='center')
                    
                    # Highlight significant results
                    if col_idx == len(row) and 'Significant' in df.columns:
                        if isinstance(value, str):
                            if value.startswith('***'):
                                cell.fill = PatternFill(
                                    start_color='FF6B6B', end_color='FF6B6B', 
                                    fill_type='solid'
                                )
                            elif value.startswith('**'):
                                cell.fill = PatternFill(
                                    start_color='FFA07A', end_color='FFA07A', 
                                    fill_type='solid'
                                )
                            elif value.startswith('*'):
                                cell.fill = PatternFill(
                                    start_color='FFD700', end_color='FFD700', 
                                    fill_type='solid'
                                )
            
            # Auto-adjust column widths
            for col in ws.columns:
                max_length = 0
                column = col[0].column_letter
                for cell in col:
                    try:
                        if len(str(cell.value)) > max_length:
                            max_length = len(cell.value)
                    except:
                        pass
                adjusted_width = min(max_length + 2, 50)
                ws.column_dimensions[column].width = adjusted_width
        
        wb.save(output_path)
```

#### 5.4 Excel Exporter (Comprehensive)

**Implementation: `core/exporters/excel_exporter.py`**

```python
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, PatternFill
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional
import pandas as pd

class ExcelExporter:
    """Exports comprehensive analysis results to Excel."""
    
    def __init__(self, parameter_selector: ExportParameterSelector,
                 stats_engine: StatisticsEngine):
        self.param_selector = parameter_selector
        self.stats = stats_engine
    
    def export(self, assay_ids: List[int], output_dir: Path,
               database: DatabaseInterface,
               dataset_split: Optional[Dict[str, str]] = None) -> Path:
        """
        Export comprehensive Excel file with all parameters and statistics.
        
        Args:
            assay_ids: List of assay IDs to export
            output_dir: Output directory
            database: Database interface
            dataset_split: Optional dict mapping markers to full names
            
        Returns:
            Path to created Excel file
        """
        # Get data
        parameters = self.param_selector.get_selected()
        df = database.get_measurements(assay_ids, parameters)
        
        # Create workbook
        wb = Workbook()
        wb.remove(wb.active)  # Remove default sheet
        
        # Generate filename
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        assay_indices = '_'.join(str(aid) for aid in sorted(assay_ids))
        filename = f'analysis_{timestamp}_assays{assay_indices}.xlsx'
        
        # Create sheets
        self._create_raw_data_sheet(wb, df)
        self._create_summary_stats_sheet(wb, df, parameters)
        self._create_frequency_sheets(wb, df, parameters)
        
        # Save
        output_path = output_dir / filename
        wb.save(output_path)
        
        return output_path
    
    def _create_raw_data_sheet(self, wb: Workbook, df: pd.DataFrame) -> None:
        """Create raw data worksheet."""
        ws = wb.create_sheet('Raw Data')
        
        # Write DataFrame to worksheet
        for r_idx, row in enumerate(df.itertuples(index=False), 1):
            for c_idx, value in enumerate(row, 1):
                ws.cell(row=r_idx, column=c_idx, value=value)
        
        # Style header
        for cell in ws[1]:
            cell.font = Font(bold=True)
            cell.fill = PatternFill(start_color='CCCCCC', fill_type='solid')
    
    def _create_summary_stats_sheet(self, wb: Workbook, 
                                   df: pd.DataFrame,
                                   parameters: List[str]) -> None:
        """Create worksheet with statistical summaries."""
        ws = wb.create_sheet('Summary Statistics')
        
        # Headers
        ws.append(['Parameter', 'Condition', 'N', 'Mean', 'SEM', 'SD', 
                  'Median', 'Min', 'Max'])
        
        # Style headers
        for cell in ws[1]:
            cell.font = Font(bold=True)
            cell.fill = PatternFill(start_color='CCCCCC', fill_type='solid')
        
        # Calculate stats for each parameter and condition
        for param in parameters:
            param_data = df[df['parameter_name'] == param]
            conditions = param_data['condition'].unique()
            
            for condition in sorted(conditions):
                cond_data = param_data[
                    param_data['condition'] == condition
                ]['value']
                stats = self.stats.calculate_summary_stats(cond_data)
                
                ws.append([
                    param,
                    condition,
                    stats['n'],
                    stats['mean'],
                    stats['sem'],
                    stats['std'],
                    stats['median'],
                    stats['min'],
                    stats['max']
                ])
    
    def _create_frequency_sheets(self, wb: Workbook, 
                                 df: pd.DataFrame,
                                 parameters: List[str]) -> None:
        """Create frequency distribution worksheets."""
        # Implementation depends on specific frequency distribution requirements
        pass
```

#### 5.5 GraphPad Prism Exporter

**Implementation: `core/exporters/graphpad_exporter.py`**

```python
import xml.etree.ElementTree as ET
from xml.dom import minidom
from datetime import datetime
from pathlib import Path
from typing import List, Dict
import pandas as pd

class GraphPadExporter:
    """Exports data in GraphPad Prism .pzfx format."""
    
    def __init__(self, parameter_selector: ExportParameterSelector):
        self.param_selector = parameter_selector
    
    def export(self, assay_ids: List[int], output_dir: Path,
               database: DatabaseInterface) -> Path:
        """
        Export .pzfx file for GraphPad Prism.
        
        Args:
            assay_ids: List of assay IDs to export
            output_dir: Output directory
            database: Database interface
            
        Returns:
            Path to created .pzfx file
        """
        # Get data
        parameters = self.param_selector.get_selected()
        df = database.get_measurements(assay_ids, parameters)
        
        # Create XML structure
        root = ET.Element('GraphPadPrismFile', {
            'xmlns': 'http://graphpad.com/prism/Prism.htm',
            'PrismXMLVersion': '5.00'
        })
        
        # Add tables for each parameter
        for param in parameters:
            self._add_parameter_table(root, df, param)
        
        # Format and save
        xml_str = self._prettify_xml(root)
        
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        assay_indices = '_'.join(str(aid) for aid in sorted(assay_ids))
        filename = f'graphpad_{timestamp}_assays{assay_indices}.pzfx'
        output_path = output_dir / filename
        
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(xml_str)
        
        return output_path
    
    def _add_parameter_table(self, root: ET.Element, 
                            df: pd.DataFrame, parameter: str) -> None:
        """Add a table for a specific parameter."""
        # Filter data for this parameter
        param_data = df[df['parameter_name'] == parameter]
        conditions = sorted(param_data['condition'].unique())
        
        # Create table element
        table = ET.SubElement(root, 'Table', {
            'ID': f'Table_{parameter}',
            'XFormat': 'none',
            'TableType': 'OneWay',
            'EVFormat': 'AsteriskAfterNumber'
        })
        
        title = ET.SubElement(table, 'Title')
        title.text = parameter
        
        # Add columns for each condition
        for condition in conditions:
            cond_data = param_data[
                param_data['condition'] == condition
            ]['value']
            
            col = ET.SubElement(table, 'YColumn', {
                'Width': '81',
                'Decimals': '2',
                'Subcolumns': '1'
            })
            
            col_title = ET.SubElement(col, 'Title')
            col_title.text = condition
            
            # Add values
            for value in cond_data:
                subcolumn = ET.SubElement(col, 'Subcolumn')
                d = ET.SubElement(subcolumn, 'd')
                d.text = str(value)
    
    def _prettify_xml(self, elem: ET.Element) -> str:
        """Return a pretty-printed XML string."""
        rough_string = ET.tostring(elem, encoding='unicode')
        reparsed = minidom.parseString(rough_string)
        return reparsed.toprettyxml(indent="  ")
```

---

