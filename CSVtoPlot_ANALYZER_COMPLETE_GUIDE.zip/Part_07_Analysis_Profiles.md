# NEUROMORPHOLOGICAL DATA ANALYZER - DEVELOPMENT GUIDE
## Part 7 of 10: Analysis Profiles

**Previous:** [Part 6 - Export Functionality]  
**Next:** [Part 8 - Representative File Analysis]

---

### 6. ANALYSIS PROFILES

#### 6.1 Profile Schema

**Implementation: `core/profiles/profile_schema.py`**

```python
from dataclasses import dataclass, asdict
from typing import Dict, List, Optional
import json

@dataclass
class AnalysisProfile:
    """Complete analysis pipeline configuration."""
    
    name: str
    description: str
    
    # Import settings
    import_parameters: List[str]
    custom_parameters: List[str]
    supported_formats: List[str] = None  # ['xls', 'xlsx', 'csv', 'json']
    
    # Plot settings
    plot_config: Dict  # PlotConfig.to_dict()
    show_scatter_dots: bool = True
    scatter_alpha: float = 0.6
    scatter_size: int = 30
    scatter_jitter: float = 0.1
    
    # Export settings
    export_config: Dict  # ExportConfig dict
    export_parameters: List[str] = None
    
    # Condition selection
    selected_conditions: Optional[List[str]] = None  # None = all
    
    # Statistics settings
    alpha: float = 0.05
    normality_test: bool = True
    post_hoc_test: str = 'tukey'
    
    # Frequency distribution settings
    frequency_bin_size: float = 10.0
    
    # Density calculation settings
    calculate_density: bool = False
    area_per_image: float = 3.5021  # μm²
    
    # Metadata
    created_date: Optional[str] = None
    modified_date: Optional[str] = None
    
    def __post_init__(self):
        """Set defaults."""
        if self.supported_formats is None:
            self.supported_formats = ['xls', 'xlsx', 'csv', 'json']
    
    def to_dict(self) -> Dict:
        """Convert to dictionary."""
        return asdict(self)
    
    def to_json(self) -> str:
        """Convert to JSON string."""
        return json.dumps(self.to_dict(), indent=2)
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'AnalysisProfile':
        """Load from dictionary."""
        return cls(**data)
    
    @classmethod
    def from_json(cls, json_str: str) -> 'AnalysisProfile':
        """Load from JSON string."""
        data = json.loads(json_str)
        return cls.from_dict(data)
```

#### 6.2 Profile Manager

**Implementation: `core/profiles/profile_manager.py`**

```python
from pathlib import Path
from typing import List, Optional
import json
from datetime import datetime

class ProfileManager:
    """Manages analysis profiles (save/load/edit/delete)."""
    
    def __init__(self, profiles_dir: Path):
        self.profiles_dir = profiles_dir
        self.profiles_dir.mkdir(parents=True, exist_ok=True)
        self.current_profile: Optional[AnalysisProfile] = None
    
    def save_profile(self, profile: AnalysisProfile, 
                    overwrite: bool = False) -> Path:
        """
        Save analysis profile to disk.
        
        Args:
            profile: AnalysisProfile to save
            overwrite: Allow overwriting existing profile
            
        Returns:
            Path to saved profile file
        """
        # Set timestamps
        now = datetime.now().isoformat()
        if not profile.created_date:
            profile.created_date = now
        profile.modified_date = now
        
        # Generate filename
        safe_name = profile.name.replace(' ', '_').replace('/', '_')
        filename = f'{safe_name}.json'
        filepath = self.profiles_dir / filename
        
        # Check if exists
        if filepath.exists() and not overwrite:
            raise FileExistsError(f"Profile already exists: {filename}")
        
        # Save
        with open(filepath, 'w') as f:
            f.write(profile.to_json())
        
        return filepath
    
    def load_profile(self, name: str) -> AnalysisProfile:
        """
        Load profile by name.
        
        Args:
            name: Profile name
            
        Returns:
            Loaded AnalysisProfile
        """
        safe_name = name.replace(' ', '_').replace('/', '_')
        filename = f'{safe_name}.json'
        filepath = self.profiles_dir / filename
        
        if not filepath.exists():
            raise FileNotFoundError(f"Profile not found: {name}")
        
        with open(filepath, 'r') as f:
            profile = AnalysisProfile.from_json(f.read())
        
        self.current_profile = profile
        return profile
    
    def list_profiles(self) -> List[str]:
        """Get list of available profile names."""
        profiles = []
        for file_path in self.profiles_dir.glob('*.json'):
            profiles.append(file_path.stem.replace('_', ' '))
        return sorted(profiles)
    
    def delete_profile(self, name: str) -> None:
        """Delete a profile."""
        safe_name = name.replace(' ', '_').replace('/', '_')
        filename = f'{safe_name}.json'
        filepath = self.profiles_dir / filename
        
        if filepath.exists():
            filepath.unlink()
    
    def duplicate_profile(self, source_name: str, 
                         new_name: str) -> AnalysisProfile:
        """Duplicate an existing profile with new name."""
        profile = self.load_profile(source_name)
        profile.name = new_name
        profile.created_date = None  # Will be set on save
        self.save_profile(profile)
        return profile
```

---

