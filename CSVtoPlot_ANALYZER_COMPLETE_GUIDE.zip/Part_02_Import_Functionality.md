# NEUROMORPHOLOGICAL DATA ANALYZER - DEVELOPMENT GUIDE
## Part 2 of 10: Import Functionality

**Previous:** [Part 1 - Overview, Architecture & Structure]  
**Next:** [Part 3 - Database Layer]

---

### 1. IMPORT FUNCTIONALITY

#### 1.1 Supported File Formats

**Requirements:**
- Support XLS, XLSX, CSV, and JSON files
- Unified interface regardless of file format
- Same parameter selection workflow for all formats
- Automatic format detection based on file extension

**File Naming Convention:**
```
Format: ExperimentIndex_Condition_ImageIndex[Marker].extension
Examples:
  - 001_Control_001.xlsx
  - 002_GST_005L.csv      (L = Liposome marker)
  - 003_Treatment_010T.json  (T = Tubule marker)
```

#### 1.2 File Scanner

**Implementation: `core/importers/file_scanner.py`**

```python
from pathlib import Path
from typing import List, Dict, Tuple
import re

class FileScanner:
    """Scans directories for morphology data files and extracts metadata."""
    
    def __init__(self, directory: Path):
        self.directory = directory
        # Updated pattern to include CSV and JSON
        self.file_pattern = re.compile(
            r'^(\d+)_([A-Za-z]+)_(\d+)([LT]?)\.(xlsx?|csv|json)$'
        )
        self.supported_extensions = {'.xls', '.xlsx', '.csv', '.json'}
    
    def scan_files(self) -> List[Dict[str, any]]:
        """
        Scan directory and return file metadata.
        
        Returns:
            List of dicts with: path, experiment_index, condition, 
            image_index, dataset_marker, file_format
        """
        files = []
        for ext in self.supported_extensions:
            for file_path in self.directory.glob(f'*{ext}'):
                metadata = self._parse_filename(file_path)
                if metadata:
                    files.append(metadata)
        return files
    
    def _parse_filename(self, file_path: Path) -> Dict[str, any]:
        """Parse filename to extract metadata."""
        match = self.file_pattern.match(file_path.name)
        if not match:
            return None
        
        return {
            'path': file_path,
            'experiment_index': int(match.group(1)),
            'condition': match.group(2),
            'image_index': int(match.group(3)),
            'dataset_marker': match.group(4) or None,  # 'L', 'T', or None
            'file_format': match.group(5)  # 'xls', 'xlsx', 'csv', 'json'
        }
    
    def detect_datasets(self, files: List[Dict]) -> List[str]:
        """
        Detect if L/T dataset markers are present.
        
        Returns:
            List of unique dataset markers found
        """
        markers = {f['dataset_marker'] for f in files if f['dataset_marker']}
        return sorted(markers)
```

#### 1.3 Header Scanner

**Implementation: `core/importers/file_scanner.py` (additional class)**

```python
import xlrd
from openpyxl import load_workbook
import pandas as pd
import json

class HeaderScanner:
    """Extracts column headers from various file formats."""
    
    @staticmethod
    def scan_headers(file_path: Path) -> List[str]:
        """
        Scan first file to get available column headers.
        
        Args:
            file_path: Path to data file
            
        Returns:
            List of column header names
        """
        ext = file_path.suffix.lower()
        
        if ext == '.xls':
            return HeaderScanner._scan_xls(file_path)
        elif ext == '.xlsx':
            return HeaderScanner._scan_xlsx(file_path)
        elif ext == '.csv':
            return HeaderScanner._scan_csv(file_path)
        elif ext == '.json':
            return HeaderScanner._scan_json(file_path)
        else:
            raise ValueError(f"Unsupported file format: {ext}")
    
    @staticmethod
    def _scan_xls(file_path: Path) -> List[str]:
        """Scan XLS file for headers."""
        workbook = xlrd.open_workbook(file_path)
        sheet = workbook.sheet_by_index(0)
        headers = [sheet.cell_value(0, col) for col in range(sheet.ncols)]
        return [h for h in headers if h]
    
    @staticmethod
    def _scan_xlsx(file_path: Path) -> List[str]:
        """Scan XLSX file for headers."""
        workbook = load_workbook(file_path, read_only=True)
        sheet = workbook.active
        headers = [cell.value for cell in sheet[1]]
        return [h for h in headers if h]
    
    @staticmethod
    def _scan_csv(file_path: Path) -> List[str]:
        """Scan CSV file for headers."""
        # Try multiple delimiters
        for delimiter in [',', ';', '\t']:
            try:
                df = pd.read_csv(file_path, sep=delimiter, nrows=0)
                if len(df.columns) > 1:  # Successfully parsed
                    return list(df.columns)
            except:
                continue
        
        # Fallback to default comma delimiter
        df = pd.read_csv(file_path, nrows=0)
        return list(df.columns)
    
    @staticmethod
    def _scan_json(file_path: Path) -> List[str]:
        """Scan JSON file for headers (keys from first measurement)."""
        with open(file_path, 'r') as f:
            data = json.load(f)
        
        # Handle different JSON structures
        if isinstance(data, dict) and 'measurements' in data:
            measurements_list = data['measurements']
        elif isinstance(data, list):
            measurements_list = data
        else:
            return []
        
        if measurements_list and len(measurements_list) > 0:
            return list(measurements_list[0].keys())
        return []
```

#### 1.4 Parameter Mapper

**Implementation: `core/importers/parameter_mapper.py`**

```python
from typing import List, Dict, Set

class ParameterMapper:
    """Manages dynamic parameter selection for import."""
    
    def __init__(self, available_headers: List[str]):
        self.available_headers = available_headers
        self.selected_parameters: Set[str] = set()
        self.custom_parameters: Set[str] = set()
    
    def select_parameters(self, parameters: List[str]) -> None:
        """
        Select parameters from available headers.
        
        Args:
            parameters: List of parameter names to select
        """
        for param in parameters:
            if param in self.available_headers:
                self.selected_parameters.add(param)
    
    def add_custom_parameter(self, parameter: str) -> None:
        """
        Add a custom parameter not in headers.
        
        Args:
            parameter: Custom parameter name
        """
        self.custom_parameters.add(parameter)
        self.selected_parameters.add(parameter)
    
    def get_all_parameters(self) -> List[str]:
        """Get all selected parameters (from headers + custom)."""
        return sorted(self.selected_parameters)
    
    def to_dict(self) -> Dict:
        """Export to dict for profile saving."""
        return {
            'available_headers': self.available_headers,
            'selected_parameters': list(self.selected_parameters),
            'custom_parameters': list(self.custom_parameters)
        }
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'ParameterMapper':
        """Load from dict (profile loading)."""
        mapper = cls(data['available_headers'])
        mapper.selected_parameters = set(data['selected_parameters'])
        mapper.custom_parameters = set(data['custom_parameters'])
        return mapper
```

#### 1.5 Excel Importer

**Implementation: `core/importers/excel_importer.py`**

```python
import pandas as pd
from typing import Dict, List, Optional, Set
from pathlib import Path
import logging

class ExcelImporter:
    """Imports data from Excel files with duplicate prevention."""
    
    def __init__(self, parameter_mapper: ParameterMapper):
        self.parameter_mapper = parameter_mapper
        self.logger = logging.getLogger(__name__)
        self.imported_records: Set[tuple] = set()
    
    def import_file(self, file_metadata: Dict) -> List[Dict]:
        """
        Import data from single Excel file.
        
        Args:
            file_metadata: Dict with path, experiment_index, condition, etc.
            
        Returns:
            List of measurement records with origin tracking
        """
        file_path = file_metadata['path']
        parameters = self.parameter_mapper.get_all_parameters()
        
        # Read file
        if file_path.suffix == '.xls':
            df = pd.read_excel(file_path, engine='xlrd')
        else:
            df = pd.read_excel(file_path, engine='openpyxl')
        
        # Extract records
        records = []
        for idx, row in df.iterrows():
            record = {
                'experiment_index': file_metadata['experiment_index'],
                'condition': file_metadata['condition'],
                'image_index': file_metadata['image_index'],
                'dataset_marker': file_metadata['dataset_marker'],
                'origin_file': str(file_path),
                'origin_row': idx + 2,  # +2 for header and 0-indexing
                'measurements': {}
            }
            
            # Extract selected parameters
            for param in parameters:
                if param in df.columns:
                    value = row[param]
                    if pd.notna(value):
                        record['measurements'][param] = float(value)
            
            # Check for duplicates
            record_signature = self._create_signature(record)
            if record_signature not in self.imported_records:
                self.imported_records.add(record_signature)
                records.append(record)
            else:
                self.logger.warning(
                    f"Duplicate record skipped: {file_path}, row {idx+2}"
                )
        
        return records
    
    def _create_signature(self, record: Dict) -> tuple:
        """Create unique signature for duplicate detection."""
        measurements_tuple = tuple(sorted(record['measurements'].items()))
        return (
            record['experiment_index'],
            record['condition'],
            record['image_index'],
            measurements_tuple
        )
    
    def import_directory(self, files_metadata: List[Dict]) -> List[Dict]:
        """Import all files from directory."""
        all_records = []
        for file_meta in files_metadata:
            records = self.import_file(file_meta)
            all_records.extend(records)
        
        self.logger.info(
            f"Imported {len(all_records)} records from {len(files_metadata)} files"
        )
        return all_records
```

#### 1.6 CSV Importer

**Implementation: `core/importers/csv_importer.py`**

```python
import pandas as pd
from pathlib import Path
from typing import List, Dict, Set
import logging

class CSVImporter:
    """Imports data from CSV files."""
    
    def __init__(self, parameter_mapper: ParameterMapper):
        self.parameter_mapper = parameter_mapper
        self.logger = logging.getLogger(__name__)
        self.imported_records: Set[tuple] = set()
    
    def import_file(self, file_metadata: Dict) -> List[Dict]:
        """
        Import data from CSV file.
        
        Args:
            file_metadata: Dict with path, experiment_index, condition, etc.
            
        Returns:
            List of measurement records with origin tracking
        """
        file_path = file_metadata['path']
        parameters = self.parameter_mapper.get_all_parameters()
        
        # Read CSV with various delimiters
        df = self._read_csv_with_delimiter_detection(file_path)
        
        # Extract records (same logic as ExcelImporter)
        records = []
        for idx, row in df.iterrows():
            record = {
                'experiment_index': file_metadata['experiment_index'],
                'condition': file_metadata['condition'],
                'image_index': file_metadata['image_index'],
                'dataset_marker': file_metadata['dataset_marker'],
                'origin_file': str(file_path),
                'origin_row': idx + 2,
                'measurements': {}
            }
            
            for param in parameters:
                if param in df.columns:
                    value = row[param]
                    if pd.notna(value):
                        record['measurements'][param] = float(value)
            
            record_signature = self._create_signature(record)
            if record_signature not in self.imported_records:
                self.imported_records.add(record_signature)
                records.append(record)
            else:
                self.logger.warning(
                    f"Duplicate record skipped: {file_path}, row {idx+2}"
                )
        
        return records
    
    def _read_csv_with_delimiter_detection(self, file_path: Path) -> pd.DataFrame:
        """Try multiple delimiters to read CSV."""
        for delimiter in [',', ';', '\t']:
            try:
                df = pd.read_csv(file_path, sep=delimiter)
                if len(df.columns) > 1:  # Successfully parsed
                    return df
            except Exception as e:
                continue
        
        # Fallback to pandas default
        try:
            return pd.read_csv(file_path)
        except Exception as e:
            self.logger.error(f"Could not parse CSV file: {file_path}")
            raise e
    
    def _create_signature(self, record: Dict) -> tuple:
        """Create unique signature for duplicate detection."""
        measurements_tuple = tuple(sorted(record['measurements'].items()))
        return (
            record['experiment_index'],
            record['condition'],
            record['image_index'],
            measurements_tuple
        )
```

#### 1.7 JSON Importer

**Implementation: `core/importers/json_importer.py`**

```python
import json
from pathlib import Path
from typing import List, Dict, Set
import logging

class JSONImporter:
    """Imports data from JSON files."""
    
    def __init__(self, parameter_mapper: ParameterMapper):
        self.parameter_mapper = parameter_mapper
        self.logger = logging.getLogger(__name__)
        self.imported_records: Set[tuple] = set()
    
    def import_file(self, file_metadata: Dict) -> List[Dict]:
        """
        Import data from JSON file.
        
        Expected JSON structure:
        {
            "measurements": [
                {"param1": value1, "param2": value2, ...},
                {"param1": value1, "param2": value2, ...}
            ]
        }
        
        OR flat structure:
        [
            {"param1": value1, "param2": value2, ...},
            {"param1": value1, "param2": value2, ...}
        ]
        """
        file_path = file_metadata['path']
        parameters = self.parameter_mapper.get_all_parameters()
        
        with open(file_path, 'r') as f:
            data = json.load(f)
        
        # Handle different JSON structures
        if isinstance(data, dict) and 'measurements' in data:
            measurements_list = data['measurements']
        elif isinstance(data, list):
            measurements_list = data
        else:
            raise ValueError(f"Unsupported JSON structure in {file_path}")
        
        records = []
        for idx, measurement in enumerate(measurements_list):
            record = {
                'experiment_index': file_metadata['experiment_index'],
                'condition': file_metadata['condition'],
                'image_index': file_metadata['image_index'],
                'dataset_marker': file_metadata['dataset_marker'],
                'origin_file': str(file_path),
                'origin_row': idx + 1,
                'measurements': {}
            }
            
            for param in parameters:
                if param in measurement:
                    value = measurement[param]
                    if value is not None:
                        record['measurements'][param] = float(value)
            
            record_signature = self._create_signature(record)
            if record_signature not in self.imported_records:
                self.imported_records.add(record_signature)
                records.append(record)
            else:
                self.logger.warning(
                    f"Duplicate record skipped: {file_path}, record {idx+1}"
                )
        
        return records
    
    def _create_signature(self, record: Dict) -> tuple:
        """Create unique signature for duplicate detection."""
        measurements_tuple = tuple(sorted(record['measurements'].items()))
        return (
            record['experiment_index'],
            record['condition'],
            record['image_index'],
            measurements_tuple
        )
```

#### 1.8 Unified Importer

**Implementation: `core/importers/unified_importer.py`**

```python
from pathlib import Path
from typing import List, Dict

class UnifiedImporter:
    """Unified importer that handles all file formats."""
    
    def __init__(self, parameter_mapper: ParameterMapper):
        self.parameter_mapper = parameter_mapper
        self.excel_importer = ExcelImporter(parameter_mapper)
        self.csv_importer = CSVImporter(parameter_mapper)
        self.json_importer = JSONImporter(parameter_mapper)
    
    def import_file(self, file_metadata: Dict) -> List[Dict]:
        """
        Import file using appropriate importer based on extension.
        
        Args:
            file_metadata: Dict with path and metadata
            
        Returns:
            List of measurement records
        """
        file_path = Path(file_metadata['path'])
        extension = file_path.suffix.lower()
        
        if extension in ['.xls', '.xlsx']:
            return self.excel_importer.import_file(file_metadata)
        elif extension == '.csv':
            return self.csv_importer.import_file(file_metadata)
        elif extension == '.json':
            return self.json_importer.import_file(file_metadata)
        else:
            raise ValueError(f"Unsupported file format: {extension}")
    
    def import_directory(self, files_metadata: List[Dict]) -> List[Dict]:
        """Import all files from directory."""
        all_records = []
        for file_meta in files_metadata:
            records = self.import_file(file_meta)
            all_records.extend(records)
        return all_records
```

---

