# NEUROMORPHOLOGICAL DATA ANALYZER - DEVELOPMENT GUIDE
## Part 3 of 10: Database Layer

**Previous:** [Part 2 - Import Functionality]  
**Next:** [Part 4 - Statistical Analysis]

---

### 2. DATABASE LAYER

#### 2.1 Abstract Database Interface

**Implementation: `core/database/base.py`**

```python
from abc import ABC, abstractmethod
from typing import List, Dict, Optional
import pandas as pd

class DatabaseInterface(ABC):
    """Abstract base class for database operations."""
    
    @abstractmethod
    def connect(self, connection_string: str) -> None:
        """Establish database connection."""
        pass
    
    @abstractmethod
    def disconnect(self) -> None:
        """Close database connection."""
        pass
    
    @abstractmethod
    def create_schema(self) -> None:
        """Create database schema (tables, indices)."""
        pass
    
    @abstractmethod
    def insert_assay(self, assay_data: Dict) -> int:
        """Insert assay and return assay_id."""
        pass
    
    @abstractmethod
    def insert_measurements(self, assay_id: int, measurements: List[Dict]) -> None:
        """Insert measurements for an assay."""
        pass
    
    @abstractmethod
    def get_assays(self, filters: Optional[Dict] = None) -> List[Dict]:
        """Retrieve assays with optional filtering."""
        pass
    
    @abstractmethod
    def get_measurements(self, assay_ids: List[int], 
                        parameters: Optional[List[str]] = None) -> pd.DataFrame:
        """Retrieve measurements as DataFrame."""
        pass
    
    @abstractmethod
    def get_available_parameters(self, assay_ids: List[int]) -> List[str]:
        """Get list of parameters present in specified assays."""
        pass
    
    @abstractmethod
    def get_conditions(self, assay_ids: List[int]) -> List[str]:
        """Get list of unique conditions in assays."""
        pass
```

#### 2.2 Database Schema

```sql
-- Assays table
CREATE TABLE assays (
    assay_id SERIAL PRIMARY KEY,
    experiment_index INTEGER NOT NULL,
    condition VARCHAR(100) NOT NULL,
    dataset_marker CHAR(1),  -- 'L', 'T', or NULL
    import_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    notes TEXT
);

-- Measurements table
CREATE TABLE measurements (
    measurement_id SERIAL PRIMARY KEY,
    assay_id INTEGER REFERENCES assays(assay_id) ON DELETE CASCADE,
    image_index INTEGER NOT NULL,
    origin_file VARCHAR(500),
    origin_row INTEGER,
    parameter_name VARCHAR(100) NOT NULL,
    value DOUBLE PRECISION NOT NULL,
    
    -- Prevent duplicates
    UNIQUE(assay_id, image_index, parameter_name, value)
);

-- Indices for performance
CREATE INDEX idx_measurements_assay ON measurements(assay_id);
CREATE INDEX idx_measurements_parameter ON measurements(parameter_name);
CREATE INDEX idx_assays_condition ON assays(condition);
CREATE INDEX idx_assays_marker ON assays(dataset_marker);
```

---

