# NEUROMORPHOLOGICAL DATA ANALYZER - DEVELOPMENT GUIDE
## Part 5 of 10: Plotting Engine

**Previous:** [Part 4 - Statistical Analysis]  
**Next:** [Part 6 - Export Functionality]

---

### 4. PLOTTING ENGINE

#### 4.1 Plot Configuration

**Implementation: `core/plotters/plot_config.py`**

**Key Concept - User-Configurable Condition Names:**
The `condition_names` dictionary allows users to define custom short→long name mappings for any condition. This is NOT hardcoded and should be configured per-analysis or saved in profiles.

Example usage:
- User has data with 'GST' condition → Sets full name to 'Gastrin Treatment'
- User has 'Ctrl' condition → Sets full name to 'Control Group'
- User has 'TreatA' condition → Sets full name to 'Treatment A: High Dose'

These mappings are:
- Configured through GUI/CLI
- Saved in analysis profiles
- Applied to plot labels and exports

```python
from typing import Dict, List, Tuple, Optional
import matplotlib.pyplot as plt
from matplotlib import colors as mcolors

class PlotConfig:
    """Configuration for plot styling and aesthetics."""
    
    DEFAULT_COLORS = {
        'Control': '#FFFFFF',  # White
        'GST': '#D3D3D3',      # Light grey
    }
    
    def __init__(self):
        self.condition_colors: Dict[str, str] = {}
        self.condition_names: Dict[str, str] = {}  # Short name -> Full display name
        self.plotting_order: List[str] = []
        self.plot_range: Optional[Tuple[float, float]] = None
        
        # Scatter plot settings
        self.show_scatter_dots: bool = True  # Default: show individual points
        self.scatter_alpha: float = 0.6  # Transparency
        self.scatter_size: int = 30  # Point size
        self.scatter_jitter: float = 0.1  # Jitter to prevent overlap
    
    def set_condition_color(self, condition: str, color: str) -> None:
        """
        Set color for a condition.
        
        Args:
            condition: Condition name
            color: Hex color code (e.g., '#FF0000')
        """
        # Validate color
        try:
            mcolors.hex2color(color)
            self.condition_colors[condition] = color
        except ValueError:
            raise ValueError(f"Invalid color code: {color}")
    
    def set_condition_colors_from_rgb(self, condition: str, 
                                     rgb: Tuple[int, int, int]) -> None:
        """
        Set color from RGB values (0-255).
        
        Args:
            condition: Condition name
            rgb: Tuple of (R, G, B) values
        """
        # Convert to hex
        hex_color = '#{:02x}{:02x}{:02x}'.format(*rgb)
        self.set_condition_color(condition, hex_color)
    
    def set_condition_name(self, short_name: str, full_name: str) -> None:
        """
        Map short condition name to full display name.
        
        This allows users to define custom aliases/expansions for condition names.
        For example: 'GST' -> 'Gastrin Treatment', 'Ctrl' -> 'Control Group'
        
        Args:
            short_name: Short condition code (as it appears in filenames/data)
            full_name: Full descriptive name for display in plots
        """
        self.condition_names[short_name] = full_name
    
    def set_plotting_order(self, order: List[str]) -> None:
        """Set order in which conditions appear in plots."""
        self.plotting_order = order
    
    def set_plot_range(self, y_min: float, y_max: float) -> None:
        """Set y-axis range for plots."""
        self.plot_range = (y_min, y_max)
    
    def set_scatter_settings(self, show: bool = True, alpha: float = 0.6,
                           size: int = 30, jitter: float = 0.1) -> None:
        """Configure scatter dot overlay settings."""
        self.show_scatter_dots = show
        self.scatter_alpha = alpha
        self.scatter_size = size
        self.scatter_jitter = jitter
    
    def get_color(self, condition: str) -> str:
        """Get color for condition (returns default if not set)."""
        if condition in self.condition_colors:
            return self.condition_colors[condition]
        elif condition in self.DEFAULT_COLORS:
            return self.DEFAULT_COLORS[condition]
        else:
            return self._generate_default_color(condition)
    
    def _generate_default_color(self, condition: str) -> str:
        """Generate a default color based on condition name hash."""
        hash_val = hash(condition) % 360
        return f'hsl({hash_val}, 70%, 60%)'
    
    def get_full_name(self, condition: str) -> str:
        """Get full display name for condition."""
        return self.condition_names.get(condition, condition)
    
    def apply_base_style(self, ax: plt.Axes) -> None:
        """
        Apply base styling to matplotlib axes.
        
        Args:
            ax: Matplotlib axes object
        """
        # Remove frame
        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)
        ax.spines['bottom'].set_visible(False)
        ax.spines['left'].set_visible(True)
        
        # Remove x-axis ticks
        ax.tick_params(axis='x', which='both', bottom=False, top=False)
        
        # Keep y-axis ticks
        ax.tick_params(axis='y', which='both', left=True, right=False)
        
        # Apply plot range if set
        if self.plot_range:
            ax.set_ylim(self.plot_range)
    
    def to_dict(self) -> Dict:
        """Export to dict for profile saving."""
        return {
            'condition_colors': self.condition_colors,
            'condition_names': self.condition_names,
            'plotting_order': self.plotting_order,
            'plot_range': list(self.plot_range) if self.plot_range else None,
            'show_scatter_dots': self.show_scatter_dots,
            'scatter_alpha': self.scatter_alpha,
            'scatter_size': self.scatter_size,
            'scatter_jitter': self.scatter_jitter
        }
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'PlotConfig':
        """Load from dict (profile loading)."""
        config = cls()
        config.condition_colors = data.get('condition_colors', {})
        config.condition_names = data.get('condition_names', {})
        config.plotting_order = data.get('plotting_order', [])
        plot_range = data.get('plot_range')
        config.plot_range = tuple(plot_range) if plot_range else None
        config.show_scatter_dots = data.get('show_scatter_dots', True)
        config.scatter_alpha = data.get('scatter_alpha', 0.6)
        config.scatter_size = data.get('scatter_size', 30)
        config.scatter_jitter = data.get('scatter_jitter', 0.1)
        return config
```

**Workflow Example - Configuring Condition Names:**

```python
# User workflow for configuring condition display names

# 1. Create plot config
plot_config = PlotConfig()

# 2. User defines their condition name mappings
# (This would typically be done through the GUI ConditionNamesWidget)
plot_config.set_condition_name('Ctrl', 'Control Group')
plot_config.set_condition_name('GST', 'Gastrin Treatment')
plot_config.set_condition_name('TreatA', 'Treatment A: High Dose 100mg')
plot_config.set_condition_name('TreatB', 'Treatment B: Low Dose 50mg')

# 3. When creating plots, full names are used for labels
# Instead of "Ctrl" on x-axis, plot shows "Control Group"
# Instead of "GST" on x-axis, plot shows "Gastrin Treatment"

# 4. These mappings are saved in analysis profiles
profile = AnalysisProfile(
    name="My Gastrin Study",
    description="Standard analysis for gastrin experiments",
    plot_config=plot_config.to_dict(),  # Includes condition_names
    # ... other settings
)

# 5. Load profile in future analysis - condition names are restored
loaded_config = PlotConfig.from_dict(profile.plot_config)
# loaded_config.get_full_name('GST') returns 'Gastrin Treatment'
```


#### 4.2 Significance Annotator

**Implementation: `core/plotters/significance_annotator.py`**

```python
import matplotlib.pyplot as plt
from typing import List, Dict
import numpy as np

class SignificanceAnnotator:
    """Adds significance brackets and stars to plots."""
    
    @staticmethod
    def get_significance_stars(p_value: float) -> str:
        """Convert p-value to star notation."""
        if p_value < 0.001:
            return '***'
        elif p_value < 0.01:
            return '**'
        elif p_value < 0.05:
            return '*'
        else:
            return ''
    
    def add_brackets(self, ax: plt.Axes, comparisons: List[Dict], 
                    positions: Dict[str, int], height_offset: float = 1.0) -> None:
        """
        Add significance brackets to plot.
        
        Args:
            ax: Matplotlib axes
            comparisons: List of comparison dicts with group1, group2, p_value
            positions: Dict mapping condition names to x positions
            height_offset: Height offset for bracket placement
        """
        # Get current y-axis limits
        y_min, y_max = ax.get_ylim()
        y_range = y_max - y_min
        
        # Sort comparisons by distance between groups
        comparisons = sorted(
            comparisons, 
            key=lambda x: abs(positions[x['group1']] - positions[x['group2']])
        )
        
        # Track bracket heights to avoid overlaps
        bracket_level = 0
        for comp in comparisons:
            if not comp.get('significant', False):
                continue
            
            group1 = comp['group1']
            group2 = comp['group2']
            p_value = comp['p_value']
            
            # Get x positions
            x1 = positions[group1]
            x2 = positions[group2]
            
            # Calculate bracket height
            bracket_height = y_max + (bracket_level * 0.05 * y_range) + (0.02 * y_range)
            
            # Draw bracket
            self._draw_bracket(ax, x1, x2, bracket_height, y_range * 0.01)
            
            # Add stars
            stars = self.get_significance_stars(p_value)
            mid_x = (x1 + x2) / 2
            ax.text(mid_x, bracket_height + y_range * 0.01, stars,
                   ha='center', va='bottom', fontsize=12, fontweight='bold')
            
            bracket_level += 1
        
        # Adjust y-axis to accommodate brackets
        if bracket_level > 0:
            new_y_max = y_max + (bracket_level * 0.05 * y_range) + (0.05 * y_range)
            ax.set_ylim(y_min, new_y_max)
    
    def _draw_bracket(self, ax: plt.Axes, x1: float, x2: float, 
                     height: float, bar_height: float) -> None:
        """Draw a single significance bracket."""
        # Horizontal line
        ax.plot([x1, x2], [height, height], 'k-', linewidth=1.5)
        
        # Vertical lines
        ax.plot([x1, x1], [height - bar_height, height], 'k-', linewidth=1.5)
        ax.plot([x2, x2], [height - bar_height, height], 'k-', linewidth=1.5)
```

#### 4.3 Box Plot Generator

**Implementation: `core/plotters/box_plotter.py`**

```python
import matplotlib.pyplot as plt
import pandas as pd
from typing import Dict, List
import numpy as np

class BoxPlotter:
    """Creates box plots with SEM and significance annotations."""
    
    def __init__(self, plot_config: PlotConfig, stats_engine: StatisticsEngine):
        self.config = plot_config
        self.stats = stats_engine
        self.annotator = SignificanceAnnotator()
    
    def create_boxplot(self, data: Dict[str, pd.Series], 
                       title: str, ylabel: str,
                       comparisons: List[Dict]) -> plt.Figure:
        """
        Create box plot with significance brackets and optional scatter overlay.
        
        Args:
            data: Dict mapping condition names to data series
            title: Plot title
            ylabel: Y-axis label
            comparisons: Statistical comparison results
            
        Returns:
            Matplotlib figure
        """
        # Determine order
        if self.config.plotting_order:
            conditions = [c for c in self.config.plotting_order if c in data]
        else:
            conditions = sorted(data.keys())
        
        # Create figure
        fig, ax = plt.subplots(figsize=(10, 6))
        
        # Prepare data for plotting
        plot_data = [data[cond] for cond in conditions]
        positions = list(range(len(conditions)))
        position_map = {cond: i for i, cond in enumerate(conditions)}
        
        # Create box plot
        bp = ax.boxplot(plot_data, positions=positions, widths=0.6,
                       patch_artist=True, showmeans=True,
                       meanprops=dict(marker='D', markerfacecolor='red', 
                                    markeredgecolor='red', markersize=6))
        
        # Color boxes
        for patch, condition in zip(bp['boxes'], conditions):
            color = self.config.get_color(condition)
            patch.set_facecolor(color)
            patch.set_edgecolor('black')
            patch.set_linewidth(1.5)
        
        # Add SEM error bars
        for i, condition in enumerate(conditions):
            series = data[condition]
            mean = series.mean()
            sem = series.sem()
            
            ax.errorbar(i, mean, yerr=sem, fmt='none', ecolor='black',
                       elinewidth=2, capsize=5, capthick=2)
        
        # Add scatter dots if enabled
        if self.config.show_scatter_dots:
            for i, condition in enumerate(conditions):
                series = data[condition]
                
                # Add jitter to x-coordinates
                np.random.seed(42)  # Reproducible jitter
                x_jitter = np.random.normal(
                    i, self.config.scatter_jitter, size=len(series)
                )
                
                # Plot individual points
                ax.scatter(x_jitter, series, 
                          alpha=self.config.scatter_alpha,
                          s=self.config.scatter_size,
                          c='black',
                          edgecolors='black',
                          linewidths=0.5,
                          zorder=3)  # Ensure dots appear on top
        
        # Add n-numbers
        for i, condition in enumerate(conditions):
            n = len(data[condition])
            ax.text(i, ax.get_ylim()[0], f'n={n}',
                   ha='center', va='top', fontsize=10)
        
        # Set x-axis labels (use full names)
        ax.set_xticks(positions)
        ax.set_xticklabels(
            [self.config.get_full_name(c) for c in conditions],
            rotation=45, ha='right'
        )
        
        # Set labels
        ax.set_ylabel(ylabel, fontsize=12, fontweight='bold')
        ax.set_title(title, fontsize=14, fontweight='bold')
        
        # Apply base styling
        self.config.apply_base_style(ax)
        
        # Add significance brackets
        self.annotator.add_brackets(ax, comparisons, position_map)
        
        plt.tight_layout()
        return fig
```

#### 4.4 Bar Plot Generator

**Implementation: `core/plotters/bar_plotter.py`**

```python
import matplotlib.pyplot as plt
import pandas as pd
from typing import Dict, List
import numpy as np

class BarPlotter:
    """Creates bar plots with SEM and significance annotations."""
    
    def __init__(self, plot_config: PlotConfig, stats_engine: StatisticsEngine):
        self.config = plot_config
        self.stats = stats_engine
        self.annotator = SignificanceAnnotator()
    
    def create_barplot(self, data: Dict[str, pd.Series], 
                       title: str, ylabel: str,
                       comparisons: List[Dict]) -> plt.Figure:
        """
        Create bar plot with significance brackets and optional scatter overlay.
        
        Args:
            data: Dict mapping condition names to data series
            title: Plot title
            ylabel: Y-axis label
            comparisons: Statistical comparison results
            
        Returns:
            Matplotlib figure
        """
        # Determine order
        if self.config.plotting_order:
            conditions = [c for c in self.config.plotting_order if c in data]
        else:
            conditions = sorted(data.keys())
        
        # Create figure
        fig, ax = plt.subplots(figsize=(10, 6))
        
        # Calculate means and SEMs
        means = [data[cond].mean() for cond in conditions]
        sems = [data[cond].sem() for cond in conditions]
        
        # Create positions
        positions = np.arange(len(conditions))
        position_map = {cond: i for i, cond in enumerate(conditions)}
        
        # Create bars
        bars = ax.bar(positions, means, width=0.6, edgecolor='black', linewidth=1.5)
        
        # Color bars
        for bar, condition in zip(bars, conditions):
            color = self.config.get_color(condition)
            bar.set_facecolor(color)
        
        # Add SEM error bars (both directions)
        ax.errorbar(positions, means, yerr=sems, fmt='none', ecolor='black',
                   elinewidth=2, capsize=5, capthick=2)
        
        # Add scatter dots if enabled
        if self.config.show_scatter_dots:
            for i, condition in enumerate(conditions):
                series = data[condition]
                
                # Add jitter
                np.random.seed(42)
                x_jitter = np.random.normal(
                    i, self.config.scatter_jitter, size=len(series)
                )
                
                # Plot individual points
                ax.scatter(x_jitter, series, 
                          alpha=self.config.scatter_alpha,
                          s=self.config.scatter_size,
                          c='black',
                          edgecolors='white',
                          linewidths=1,
                          zorder=3)
        
        # Add n-numbers
        for i, condition in enumerate(conditions):
            n = len(data[condition])
            ax.text(i, ax.get_ylim()[0], f'n={n}',
                   ha='center', va='top', fontsize=10)
        
        # Set x-axis labels
        ax.set_xticks(positions)
        ax.set_xticklabels(
            [self.config.get_full_name(c) for c in conditions],
            rotation=45, ha='right'
        )
        
        # Set labels
        ax.set_ylabel(ylabel, fontsize=12, fontweight='bold')
        ax.set_title(title, fontsize=14, fontweight='bold')
        
        # Apply base styling
        self.config.apply_base_style(ax)
        
        # Add significance brackets
        self.annotator.add_brackets(ax, comparisons, position_map)
        
        plt.tight_layout()
        return fig
```

#### 4.5 Frequency Distribution Plotter

**Implementation: `core/plotters/frequency_plotter.py`**

```python
import matplotlib.pyplot as plt
import pandas as pd
from typing import Dict, Optional
import numpy as np

class FrequencyPlotter:
    """Creates frequency distribution plots."""
    
    def __init__(self, plot_config: PlotConfig):
        self.config = plot_config
        self.annotator = SignificanceAnnotator()
    
    def create_frequency_plot(self, distributions: Dict[str, pd.DataFrame],
                            title: str, value_type: str = 'count',
                            bin_comparisons: Optional[pd.DataFrame] = None) -> plt.Figure:
        """
        Create frequency distribution plot.
        
        Args:
            distributions: Dict mapping conditions to frequency DataFrames
            title: Plot title
            value_type: 'count' or 'relative'
            bin_comparisons: DataFrame with per-bin significance results
            
        Returns:
            Matplotlib figure
        """
        # Determine order
        if self.config.plotting_order:
            conditions = [c for c in self.config.plotting_order if c in distributions]
        else:
            conditions = sorted(distributions.keys())
        
        # Create figure
        fig, ax = plt.subplots(figsize=(12, 6))
        
        # Get all bins
        all_bins = set()
        for dist in distributions.values():
            all_bins.update(zip(dist['bin_start'], dist['bin_end']))
        all_bins = sorted(all_bins)
        
        # Create grouped bar chart
        n_conditions = len(conditions)
        n_bins = len(all_bins)
        bar_width = 0.8 / n_conditions
        
        x = np.arange(n_bins)
        
        for i, condition in enumerate(conditions):
            dist = distributions[condition]
            
            # Extract values for each bin
            values = []
            for bin_start, bin_end in all_bins:
                row = dist[(dist['bin_start'] == bin_start) & 
                          (dist['bin_end'] == bin_end)]
                if not row.empty:
                    if value_type == 'count':
                        values.append(row['count'].values[0])
                    else:
                        values.append(row['relative_freq'].values[0])
                else:
                    values.append(0)
            
            # Plot bars
            offset = (i - n_conditions/2 + 0.5) * bar_width
            color = self.config.get_color(condition)
            ax.bar(x + offset, values, bar_width, 
                  label=self.config.get_full_name(condition),
                  color=color, edgecolor='black', linewidth=1)
        
        # Set x-axis labels (bin ranges)
        bin_labels = [f'{start:.0f}-{end:.0f}' for start, end in all_bins]
        ax.set_xticks(x)
        ax.set_xticklabels(bin_labels, rotation=45, ha='right')
        
        # Labels
        ax.set_xlabel('Bin Range', fontsize=12, fontweight='bold')
        ylabel = 'Count' if value_type == 'count' else 'Relative Frequency'
        ax.set_ylabel(ylabel, fontsize=12, fontweight='bold')
        ax.set_title(title, fontsize=14, fontweight='bold')
        
        # Legend
        ax.legend(frameon=False)
        
        # Apply base styling
        self.config.apply_base_style(ax)
        
        # Add significance markers if provided
        if bin_comparisons is not None:
            self._add_bin_significance_markers(ax, bin_comparisons, x)
        
        plt.tight_layout()
        return fig
    
    def _add_bin_significance_markers(self, ax: plt.Axes, 
                                     bin_comparisons: pd.DataFrame,
                                     bin_positions: np.ndarray) -> None:
        """Add significance markers above bins."""
        y_max = ax.get_ylim()[1]
        
        for idx, row in bin_comparisons.iterrows():
            if row['significant']:
                stars = self.annotator.get_significance_stars(row['p_value'])
                if stars:
                    ax.text(bin_positions[idx], y_max * 0.95, stars,
                           ha='center', va='top', fontsize=10, fontweight='bold')
```

#### 4.6 Plot Exporter (High Resolution)

**Implementation: `core/plotters/plot_exporter.py`**

```python
from pathlib import Path
import matplotlib.pyplot as plt
from typing import List, Dict

class PlotExporter:
    """Exports plots in high-resolution formats."""
    
    DEFAULT_DPI = 800
    SUPPORTED_FORMATS = ['png', 'tif', 'tiff', 'pdf', 'svg']
    
    def __init__(self, output_dir: Path, dpi: int = DEFAULT_DPI):
        self.output_dir = output_dir
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.dpi = dpi
    
    def export_figure(self, fig: plt.Figure, 
                     base_name: str,
                     formats: List[str] = ['png', 'tif']) -> List[Path]:
        """
        Export matplotlib figure in multiple formats at 800 DPI.
        
        Args:
            fig: Matplotlib figure to export
            base_name: Base filename (without extension)
            formats: List of formats to export ['png', 'tif', 'pdf', 'svg']
            
        Returns:
            List of paths to exported files
        """
        exported_files = []
        
        for fmt in formats:
            if fmt not in self.SUPPORTED_FORMATS:
                raise ValueError(f"Unsupported format: {fmt}")
            
            # Normalize format name
            if fmt == 'tiff':
                fmt = 'tif'
            
            output_path = self.output_dir / f"{base_name}.{fmt}"
            
            # Export with high DPI
            fig.savefig(output_path, 
                       dpi=self.dpi,
                       format=fmt,
                       bbox_inches='tight',
                       facecolor='white',
                       edgecolor='none',
                       transparent=False)
            
            exported_files.append(output_path)
        
        return exported_files
    
    def export_multiple_figures(self, figures: Dict[str, plt.Figure],
                                formats: List[str] = ['png', 'tif']) -> Dict[str, List[Path]]:
        """
        Export multiple figures at once.
        
        Args:
            figures: Dict mapping base names to figures
            formats: Export formats
            
        Returns:
            Dict mapping base names to lists of exported file paths
        """
        results = {}
        for name, fig in figures.items():
            results[name] = self.export_figure(fig, name, formats)
        return results
```

---

