# NEUROMORPHOLOGICAL DATA ANALYZER - DEVELOPMENT GUIDE
## Part 4 of 10: Statistical Analysis

**Previous:** [Part 3 - Database Layer]  
**Next:** [Part 5 - Plotting Engine]

---

### 3. STATISTICAL ANALYSIS

#### 3.1 Statistics Engine

**Implementation: `core/processors/statistics.py`**

```python
import pandas as pd
import numpy as np
from scipy import stats
from statsmodels.stats.multicomp import pairwise_tukeyhsd
from typing import Dict, List, Tuple
import logging

class StatisticsEngine:
    """Performs statistical analysis on neuromorphological data."""
    
    def __init__(self, alpha: float = 0.05):
        self.alpha = alpha
        self.logger = logging.getLogger(__name__)
    
    def test_normality(self, data: pd.Series) -> Tuple[bool, float]:
        """
        Test normality using Shapiro-Wilk test.
        
        Args:
            data: Series of values
            
        Returns:
            (is_normal, p_value)
        """
        if len(data) < 3:
            return False, np.nan
        
        statistic, p_value = stats.shapiro(data)
        is_normal = p_value > self.alpha
        
        return is_normal, p_value
    
    def anova_one_way(self, groups: Dict[str, pd.Series]) -> Dict:
        """
        Perform one-way ANOVA.
        
        Args:
            groups: Dict mapping condition names to data series
            
        Returns:
            Dict with f_statistic, p_value, is_significant
        """
        # Check normality for each group
        normality_results = {}
        for name, data in groups.items():
            is_normal, p_val = self.test_normality(data)
            normality_results[name] = {'is_normal': is_normal, 'p_value': p_val}
        
        # Perform ANOVA
        f_statistic, p_value = stats.f_oneway(*groups.values())
        
        result = {
            'f_statistic': f_statistic,
            'p_value': p_value,
            'is_significant': p_value < self.alpha,
            'normality_tests': normality_results
        }
        
        # Log warning if normality violated
        if not all(r['is_normal'] for r in normality_results.values()):
            self.logger.warning(
                "Normality assumption violated for one or more groups"
            )
        
        return result
    
    def tukey_hsd(self, data: pd.DataFrame, value_col: str, 
                  group_col: str) -> pd.DataFrame:
        """
        Perform Tukey HSD post-hoc test.
        
        Args:
            data: DataFrame with values and group labels
            value_col: Name of value column
            group_col: Name of group column
            
        Returns:
            DataFrame with pairwise comparisons
        """
        tukey = pairwise_tukeyhsd(
            endog=data[value_col],
            groups=data[group_col],
            alpha=self.alpha
        )
        
        # Convert to DataFrame
        results = pd.DataFrame(
            data=tukey.summary().data[1:], 
            columns=tukey.summary().data[0]
        )
        
        # Add significance column
        results['significant'] = results['p-adj'] < self.alpha
        
        # Only keep significant results
        results = results[results['significant']].copy()
        
        return results
    
    def pairwise_comparisons(self, groups: Dict[str, pd.Series]) -> List[Dict]:
        """
        Perform pairwise statistical comparisons.
        
        Args:
            groups: Dict mapping condition names to data series
            
        Returns:
            List of comparison results (only significant ones)
        """
        # Create DataFrame for Tukey
        data_list = []
        for name, series in groups.items():
            for value in series:
                data_list.append({'value': value, 'group': name})
        
        df = pd.DataFrame(data_list)
        
        # Run Tukey HSD
        tukey_results = self.tukey_hsd(df, 'value', 'group')
        
        # Format results
        comparisons = []
        for _, row in tukey_results.iterrows():
            comparisons.append({
                'group1': row['group1'],
                'group2': row['group2'],
                'mean_diff': row['meandiff'],
                'p_value': row['p-adj'],
                'significant': True  # Only significant ones in filtered results
            })
        
        return comparisons
    
    def calculate_summary_stats(self, data: pd.Series) -> Dict:
        """
        Calculate summary statistics for a dataset.
        
        Returns:
            Dict with mean, sem, std, median, n, etc.
        """
        return {
            'n': len(data),
            'mean': data.mean(),
            'sem': data.sem(),
            'std': data.std(),
            'median': data.median(),
            'min': data.min(),
            'max': data.max(),
            'q25': data.quantile(0.25),
            'q75': data.quantile(0.75)
        }
```

#### 3.2 Frequency Distribution Analyzer

**Implementation: `core/processors/statistics.py` (additional class)**

```python
class FrequencyAnalyzer:
    """Analyzes frequency distributions for morphological parameters."""
    
    def __init__(self, bin_size: float = 10.0):
        self.bin_size = bin_size
        self.stats_engine = StatisticsEngine()
    
    def create_frequency_distribution(self, data: pd.Series, 
                                      bin_size: Optional[float] = None) -> pd.DataFrame:
        """
        Create frequency distribution with specified bin size.
        
        Args:
            data: Series of values
            bin_size: Bin width (uses default if None)
            
        Returns:
            DataFrame with bin_start, bin_end, count, relative_freq
        """
        if bin_size is None:
            bin_size = self.bin_size
        
        # Create bins
        min_val = data.min()
        max_val = data.max()
        bins = np.arange(min_val, max_val + bin_size, bin_size)
        
        # Calculate histogram
        counts, bin_edges = np.histogram(data, bins=bins)
        
        # Create DataFrame
        freq_df = pd.DataFrame({
            'bin_start': bin_edges[:-1],
            'bin_end': bin_edges[1:],
            'count': counts,
            'relative_freq': counts / counts.sum()
        })
        
        return freq_df
    
    def compare_distributions_per_bin(self, 
                                      distributions: Dict[str, pd.DataFrame]) -> pd.DataFrame:
        """
        Perform statistical comparisons per bin across conditions.
        
        Args:
            distributions: Dict mapping condition names to frequency DataFrames
            
        Returns:
            DataFrame with bin ranges and significance results
        """
        # Get common bins across all distributions
        all_bins = set()
        for dist in distributions.values():
            all_bins.update(zip(dist['bin_start'], dist['bin_end']))
        
        all_bins = sorted(all_bins)
        
        results = []
        for bin_start, bin_end in all_bins:
            # Extract counts for this bin from each condition
            bin_counts = {}
            for condition, dist in distributions.items():
                row = dist[(dist['bin_start'] == bin_start) & 
                          (dist['bin_end'] == bin_end)]
                if not row.empty:
                    bin_counts[condition] = row['count'].values[0]
                else:
                    bin_counts[condition] = 0
            
            # Perform chi-square test for this bin
            counts = list(bin_counts.values())
            if sum(counts) > 0:
                chi2, p_value = stats.chisquare(counts)
                significant = p_value < self.stats_engine.alpha
            else:
                chi2, p_value, significant = np.nan, np.nan, False
            
            results.append({
                'bin_start': bin_start,
                'bin_end': bin_end,
                'chi2': chi2,
                'p_value': p_value,
                'significant': significant,
                **bin_counts
            })
        
        return pd.DataFrame(results)
```

---

