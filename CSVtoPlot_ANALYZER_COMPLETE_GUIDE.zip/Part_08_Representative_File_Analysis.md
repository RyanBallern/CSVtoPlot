# NEUROMORPHOLOGICAL DATA ANALYZER - DEVELOPMENT GUIDE
## Part 8 of 10: Representative File Analysis

**Previous:** [Part 7 - Analysis Profiles]  
**Next:** [Part 9 - GUI Components]

---

### 7. REPRESENTATIVE FILE ANALYSIS

**Implementation: `core/processors/representative_files.py`**

```python
import pandas as pd
import numpy as np
from typing import Dict, List
from scipy.spatial.distance import euclidean
from pathlib import Path

class RepresentativeFileAnalyzer:
    """Finds most representative files per condition."""
    
    def __init__(self, database: DatabaseInterface):
        self.database = database
    
    def analyze(self, assay_ids: List[int], 
                parameters: List[str]) -> pd.DataFrame:
        """
        Find representative files for each condition.
        
        Args:
            assay_ids: List of assay IDs to analyze
            parameters: Parameters to consider
            
        Returns:
            DataFrame with ranked files per condition
        """
        # Get all measurements
        df = self.database.get_measurements(assay_ids, parameters)
        
        results = []
        
        # Process each condition
        for condition in df['condition'].unique():
            cond_data = df[df['condition'] == condition]
            
            # Calculate average values for each parameter
            averages = {}
            for param in parameters:
                param_data = cond_data[cond_data['parameter_name'] == param]
                averages[param] = param_data['value'].mean()
            
            # Calculate distance for each file
            files = cond_data['origin_file'].unique()
            file_distances = []
            
            for file in files:
                file_data = cond_data[cond_data['origin_file'] == file]
                
                # Build vector of parameter values
                file_vector = []
                for param in parameters:
                    param_values = file_data[
                        file_data['parameter_name'] == param
                    ]['value']
                    if len(param_values) > 0:
                        file_vector.append(param_values.mean())
                    else:
                        file_vector.append(0)
                
                # Build average vector
                avg_vector = [averages.get(param, 0) for param in parameters]
                
                # Calculate Euclidean distance
                distance = euclidean(file_vector, avg_vector)
                
                file_distances.append({
                    'condition': condition,
                    'file': file,
                    'distance_from_average': distance
                })
            
            # Sort by distance (ascending = most representative first)
            file_distances_sorted = sorted(
                file_distances, 
                key=lambda x: x['distance_from_average']
            )
            
            # Add rank
            for rank, item in enumerate(file_distances_sorted, 1):
                item['rank'] = rank
                results.append(item)
        
        return pd.DataFrame(results)
    
    def export_to_csv(self, results: pd.DataFrame, output_path: Path) -> None:
        """Export representative files list to CSV."""
        results.to_csv(output_path, index=False)
```

---

