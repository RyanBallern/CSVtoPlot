# NEUROMORPHOLOGICAL DATA ANALYZER - DEVELOPMENT GUIDE
## Part 9 of 10: GUI Components

**Previous:** [Part 8 - Representative File Analysis]  
**Next:** [Part 10 - Roadmap, Testing & Documentation]

---

### 8. GUI COMPONENTS

#### 8.1 Condition Names Manager Widget

**Implementation: `gui/widgets/condition_names_widget.py`**

This widget allows users to configure short→long name mappings for conditions.

```python
import tkinter as tk
from tkinter import ttk
from typing import Dict, Callable, Optional

class ConditionNamesWidget(ttk.Frame):
    """Widget for configuring condition short→long name mappings."""
    
    def __init__(self, parent, conditions: List[str], 
                 callback: Optional[Callable] = None):
        super().__init__(parent)
        self.conditions = conditions
        self.callback = callback
        self.name_entries: Dict[str, tk.StringVar] = {}
        
        self._create_widgets()
    
    def _create_widgets(self):
        """Create input fields for each condition."""
        ttk.Label(
            self, text="Condition Display Names:", 
            font=('TkDefaultFont', 10, 'bold')
        ).grid(row=0, column=0, columnspan=3, sticky='w', pady=5)
        
        ttk.Label(self, text="Short Name").grid(row=1, column=0, sticky='w', padx=5)
        ttk.Label(self, text="Full Display Name").grid(row=1, column=1, sticky='w', padx=5)
        
        # Create row for each condition
        for idx, condition in enumerate(self.conditions, start=2):
            # Short name (read-only)
            ttk.Label(self, text=condition).grid(row=idx, column=0, sticky='w', padx=5, pady=2)
            
            # Full name (editable)
            name_var = tk.StringVar(value=condition)  # Default to short name
            self.name_entries[condition] = name_var
            
            entry = ttk.Entry(self, textvariable=name_var, width=40)
            entry.grid(row=idx, column=1, sticky='ew', padx=5, pady=2)
            entry.bind('<FocusOut>', lambda e: self._on_change())
            
            # Reset button
            ttk.Button(
                self, text="Reset", 
                command=lambda c=condition: self._reset_condition(c),
                width=8
            ).grid(row=idx, column=2, padx=5, pady=2)
        
        self.columnconfigure(1, weight=1)
    
    def _reset_condition(self, condition: str):
        """Reset condition to its short name."""
        self.name_entries[condition].set(condition)
        self._on_change()
    
    def _on_change(self):
        """Called when any entry changes."""
        if self.callback:
            self.callback()
    
    def get_condition_names(self) -> Dict[str, str]:
        """Get dictionary of short→full name mappings."""
        mappings = {}
        for short_name, var in self.name_entries.items():
            full_name = var.get().strip()
            if full_name and full_name != short_name:
                mappings[short_name] = full_name
        return mappings
    
    def set_condition_names(self, mappings: Dict[str, str]):
        """Set condition names from dictionary."""
        for short_name, full_name in mappings.items():
            if short_name in self.name_entries:
                self.name_entries[short_name].set(full_name)
    
    def update_conditions(self, new_conditions: List[str]):
        """Update available conditions."""
        # Clear existing
        for widget in self.winfo_children():
            widget.destroy()
        
        self.conditions = new_conditions
        self.name_entries = {}
        self._create_widgets()
```

**Usage Example in Main GUI:**
```python
# In plot configuration dialog
condition_names_widget = ConditionNamesWidget(
    parent=dialog,
    conditions=['Control', 'GST', 'TreatmentA'],
    callback=self.on_names_changed
)

# Get mappings for PlotConfig
mappings = condition_names_widget.get_condition_names()
for short, full in mappings.items():
    plot_config.set_condition_name(short, full)
```

#### 8.2 Color Picker Widget

**Implementation: `gui/widgets/color_picker.py`**

```python
import tkinter as tk
from tkinter import ttk
from typing import Callable, Optional

class ColorPickerWidget(ttk.Frame):
    """RGB color picker with live preview."""
    
    def __init__(self, parent, initial_color: str = '#FFFFFF', 
                 callback: Optional[Callable] = None):
        super().__init__(parent)
        self.callback = callback
        self.current_color = initial_color
        
        # RGB sliders
        self.r_var = tk.IntVar(value=255)
        self.g_var = tk.IntVar(value=255)
        self.b_var = tk.IntVar(value=255)
        
        self._create_widgets()
        self._set_color_from_hex(initial_color)
    
    def _create_widgets(self):
        """Create RGB sliders and preview."""
        # R slider
        ttk.Label(self, text='R:').grid(row=0, column=0, sticky='w')
        r_slider = ttk.Scale(
            self, from_=0, to=255, orient='horizontal',
            variable=self.r_var, command=self._on_color_change
        )
        r_slider.grid(row=0, column=1, sticky='ew', padx=5)
        ttk.Label(self, textvariable=self.r_var).grid(row=0, column=2)
        
        # G slider
        ttk.Label(self, text='G:').grid(row=1, column=0, sticky='w')
        g_slider = ttk.Scale(
            self, from_=0, to=255, orient='horizontal',
            variable=self.g_var, command=self._on_color_change
        )
        g_slider.grid(row=1, column=1, sticky='ew', padx=5)
        ttk.Label(self, textvariable=self.g_var).grid(row=1, column=2)
        
        # B slider
        ttk.Label(self, text='B:').grid(row=2, column=0, sticky='w')
        b_slider = ttk.Scale(
            self, from_=0, to=255, orient='horizontal',
            variable=self.b_var, command=self._on_color_change
        )
        b_slider.grid(row=2, column=1, sticky='ew', padx=5)
        ttk.Label(self, textvariable=self.b_var).grid(row=2, column=2)
        
        # Hex display
        self.hex_label = ttk.Label(self, text='#FFFFFF', font=('Courier', 12))
        self.hex_label.grid(row=3, column=0, columnspan=3, pady=5)
        
        # Color preview
        self.preview = tk.Canvas(self, width=100, height=50, bg='white')
        self.preview.grid(row=4, column=0, columnspan=3, pady=5)
    
    def _on_color_change(self, *args):
        """Update preview when sliders change."""
        r = self.r_var.get()
        g = self.g_var.get()
        b = self.b_var.get()
        
        hex_color = f'#{r:02x}{g:02x}{b:02x}'
        self.current_color = hex_color
        
        # Update preview
        self.preview.configure(bg=hex_color)
        self.hex_label.configure(text=hex_color)
        
        # Callback
        if self.callback:
            self.callback(hex_color)
    
    def _set_color_from_hex(self, hex_color: str):
        """Set sliders from hex color."""
        hex_color = hex_color.lstrip('#')
        r = int(hex_color[0:2], 16)
        g = int(hex_color[2:4], 16)
        b = int(hex_color[4:6], 16)
        
        self.r_var.set(r)
        self.g_var.set(g)
        self.b_var.set(b)
    
    def get_color(self) -> str:
        """Get current color as hex."""
        return self.current_color
```

#### 8.3 Export Configuration Widget

**Implementation: `gui/widgets/export_config_widget.py`**

```python
import tkinter as tk
from tkinter import ttk
from typing import Callable, Optional

class ExportConfigWidget(ttk.Frame):
    """Widget for configuring export options."""
    
    def __init__(self, parent, callback: Optional[Callable] = None):
        super().__init__(parent)
        self.callback = callback
        
        # Variables
        self.export_excel_var = tk.BooleanVar(value=True)
        self.export_graphpad_var = tk.BooleanVar(value=False)
        self.export_csv_var = tk.BooleanVar(value=False)
        self.export_stats_var = tk.BooleanVar(value=True)
        self.export_plots_var = tk.BooleanVar(value=True)
        
        # Plot type variables
        self.plot_boxplot_total_var = tk.BooleanVar(value=True)
        self.plot_boxplot_relative_var = tk.BooleanVar(value=True)
        self.plot_barplot_total_var = tk.BooleanVar(value=True)
        self.plot_barplot_relative_var = tk.BooleanVar(value=True)
        self.plot_freq_count_var = tk.BooleanVar(value=True)
        self.plot_freq_relative_var = tk.BooleanVar(value=True)
        
        # Plot format variables
        self.plot_png_var = tk.BooleanVar(value=True)
        self.plot_tif_var = tk.BooleanVar(value=True)
        self.plot_pdf_var = tk.BooleanVar(value=False)
        self.plot_svg_var = tk.BooleanVar(value=False)
        
        self.plot_dpi_var = tk.IntVar(value=800)
        
        self._create_widgets()
    
    def _create_widgets(self):
        """Create all widgets."""
        # Export Formats Section
        formats_frame = ttk.LabelFrame(self, text="Export Formats", padding=10)
        formats_frame.grid(row=0, column=0, sticky='ew', padx=5, pady=5)
        
        ttk.Checkbutton(
            formats_frame, text="Excel (.xlsx)", 
            variable=self.export_excel_var
        ).grid(row=0, column=0, sticky='w')
        ttk.Checkbutton(
            formats_frame, text="GraphPad Prism (.pzfx)", 
            variable=self.export_graphpad_var
        ).grid(row=1, column=0, sticky='w')
        ttk.Checkbutton(
            formats_frame, text="CSV", 
            variable=self.export_csv_var
        ).grid(row=2, column=0, sticky='w')
        ttk.Checkbutton(
            formats_frame, text="Statistical Tables", 
            variable=self.export_stats_var
        ).grid(row=3, column=0, sticky='w')
        
        # Plot Types Section
        plots_frame = ttk.LabelFrame(self, text="Plot Types", padding=10)
        plots_frame.grid(row=1, column=0, sticky='ew', padx=5, pady=5)
        
        ttk.Checkbutton(
            plots_frame, text="Export Plots", 
            variable=self.export_plots_var,
            command=self._toggle_plot_options
        ).grid(row=0, column=0, columnspan=2, sticky='w')
        
        self.plot_options_frame = ttk.Frame(plots_frame)
        self.plot_options_frame.grid(row=1, column=0, columnspan=2, sticky='ew', padx=20)
        
        ttk.Checkbutton(
            self.plot_options_frame, text="Box Plot - Total Length", 
            variable=self.plot_boxplot_total_var
        ).grid(row=0, column=0, sticky='w')
        ttk.Checkbutton(
            self.plot_options_frame, text="Box Plot - Relative Length", 
            variable=self.plot_boxplot_relative_var
        ).grid(row=1, column=0, sticky='w')
        ttk.Checkbutton(
            self.plot_options_frame, text="Bar Plot - Total Length", 
            variable=self.plot_barplot_total_var
        ).grid(row=2, column=0, sticky='w')
        ttk.Checkbutton(
            self.plot_options_frame, text="Bar Plot - Relative Length", 
            variable=self.plot_barplot_relative_var
        ).grid(row=3, column=0, sticky='w')
        ttk.Checkbutton(
            self.plot_options_frame, text="Frequency Distribution - Count", 
            variable=self.plot_freq_count_var
        ).grid(row=4, column=0, sticky='w')
        ttk.Checkbutton(
            self.plot_options_frame, text="Frequency Distribution - Relative", 
            variable=self.plot_freq_relative_var
        ).grid(row=5, column=0, sticky='w')
        
        # Plot Format Section
        format_frame = ttk.LabelFrame(
            self.plot_options_frame, text="Plot Formats", padding=5
        )
        format_frame.grid(row=6, column=0, sticky='ew', pady=5)
        
        ttk.Checkbutton(
            format_frame, text="PNG", 
            variable=self.plot_png_var
        ).grid(row=0, column=0, sticky='w')
        ttk.Checkbutton(
            format_frame, text="TIF", 
            variable=self.plot_tif_var
        ).grid(row=0, column=1, sticky='w')
        ttk.Checkbutton(
            format_frame, text="PDF", 
            variable=self.plot_pdf_var
        ).grid(row=1, column=0, sticky='w')
        ttk.Checkbutton(
            format_frame, text="SVG", 
            variable=self.plot_svg_var
        ).grid(row=1, column=1, sticky='w')
        
        # DPI Setting
        dpi_frame = ttk.Frame(format_frame)
        dpi_frame.grid(row=2, column=0, columnspan=2, sticky='ew', pady=5)
        ttk.Label(dpi_frame, text="DPI:").grid(row=0, column=0, sticky='w')
        ttk.Entry(
            dpi_frame, textvariable=self.plot_dpi_var, width=10
        ).grid(row=0, column=1, sticky='w', padx=5)
    
    def _toggle_plot_options(self):
        """Enable/disable plot options based on export_plots checkbox."""
        state = 'normal' if self.export_plots_var.get() else 'disabled'
        for child in self.plot_options_frame.winfo_children():
            if isinstance(child, (ttk.Checkbutton, ttk.LabelFrame)):
                try:
                    child.configure(state=state)
                except:
                    pass
    
    def get_config(self) -> ExportConfig:
        """Get ExportConfig from widget state."""
        plot_types = set()
        if self.plot_boxplot_total_var.get():
            plot_types.add('boxplot_total')
        if self.plot_boxplot_relative_var.get():
            plot_types.add('boxplot_relative')
        if self.plot_barplot_total_var.get():
            plot_types.add('barplot_total')
        if self.plot_barplot_relative_var.get():
            plot_types.add('barplot_relative')
        if self.plot_freq_count_var.get():
            plot_types.add('frequency_count')
        if self.plot_freq_relative_var.get():
            plot_types.add('frequency_relative')
        
        plot_formats = []
        if self.plot_png_var.get():
            plot_formats.append('png')
        if self.plot_tif_var.get():
            plot_formats.append('tif')
        if self.plot_pdf_var.get():
            plot_formats.append('pdf')
        if self.plot_svg_var.get():
            plot_formats.append('svg')
        
        return ExportConfig(
            export_excel=self.export_excel_var.get(),
            export_graphpad=self.export_graphpad_var.get(),
            export_csv=self.export_csv_var.get(),
            export_statistics_tables=self.export_stats_var.get(),
            export_plots=self.export_plots_var.get(),
            plot_types=plot_types,
            plot_formats=plot_formats,
            plot_dpi=self.plot_dpi_var.get()
        )
```

#### 8.4 Condition Selector Widget

**Implementation: `gui/widgets/condition_selector_widget.py`**

```python
import tkinter as tk
from tkinter import ttk
from typing import List, Callable, Optional

class ConditionSelectorWidget(ttk.Frame):
    """Widget for selecting which conditions to include in analysis/export."""
    
    def __init__(self, parent, conditions: List[str], 
                 callback: Optional[Callable] = None):
        super().__init__(parent)
        self.conditions = conditions
        self.callback = callback
        self.condition_vars = {}
        
        self._create_widgets()
    
    def _create_widgets(self):
        """Create checkboxes for each condition."""
        ttk.Label(
            self, text="Select Conditions:", 
            font=('TkDefaultFont', 10, 'bold')
        ).grid(row=0, column=0, sticky='w', pady=5)
        
        # Select All / Deselect All buttons
        button_frame = ttk.Frame(self)
        button_frame.grid(row=1, column=0, sticky='ew', pady=5)
        
        ttk.Button(
            button_frame, text="Select All", 
            command=self._select_all
        ).grid(row=0, column=0, padx=5)
        ttk.Button(
            button_frame, text="Deselect All", 
            command=self._deselect_all
        ).grid(row=0, column=1, padx=5)
        
        # Condition checkboxes
        checkbox_frame = ttk.Frame(self)
        checkbox_frame.grid(row=2, column=0, sticky='ew')
        
        for idx, condition in enumerate(self.conditions):
            var = tk.BooleanVar(value=True)  # All selected by default
            self.condition_vars[condition] = var
            
            ttk.Checkbutton(
                checkbox_frame, text=condition, 
                variable=var,
                command=self._on_change
            ).grid(row=idx, column=0, sticky='w', pady=2)
    
    def _select_all(self):
        """Select all conditions."""
        for var in self.condition_vars.values():
            var.set(True)
        if self.callback:
            self.callback()
    
    def _deselect_all(self):
        """Deselect all conditions."""
        for var in self.condition_vars.values():
            var.set(False)
        if self.callback:
            self.callback()
    
    def _on_change(self):
        """Called when checkbox state changes."""
        if self.callback:
            self.callback()
    
    def get_selected_conditions(self) -> List[str]:
        """Get list of selected conditions."""
        return [cond for cond, var in self.condition_vars.items() if var.get()]
    
    def update_conditions(self, new_conditions: List[str]):
        """Update available conditions."""
        # Clear existing
        for widget in self.winfo_children():
            if isinstance(widget, ttk.Frame):
                for child in widget.winfo_children():
                    child.destroy()
        
        self.conditions = new_conditions
        self.condition_vars = {}
        self._create_widgets()
```

---

